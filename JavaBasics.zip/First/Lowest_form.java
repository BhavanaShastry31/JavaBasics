package First;

import java.util.Scanner;

public class Lowest_form {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the value of n: ");
		int n=sc.nextInt();
		System.out.println("enter the value of d: ");
		int d=sc.nextInt();
		
		if(n%d==0) {
			System.out.println(n/d);
		}
		else {
			if(d%n==0) {
				d=d/n;
				n=1;
				System.out.println(n+"/"+d);
			}
			else {
				System.out.println(n+"/"+d);
			}
		}
		
	}

}
