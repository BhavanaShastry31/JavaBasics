package First;

public class PrimeNumbers {
	public static void main(String[] args) {
		System.out.println(1);
		System.out.println(2);
		for(int i=2;i<=100;i++) {
			int count=0;
			for(int j=2;j<i;j++) {
				if(i%j!=0) {
					count=count+1;
				}
			if(count==(i-2) ){
				System.out.println(i);
			}
			}
		}
	}

}
