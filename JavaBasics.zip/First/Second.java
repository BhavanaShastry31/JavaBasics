package First;

import java.util.Scanner;

public class Second {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the num: ");
		int num=sc.nextInt();
		if(num<0) {
			System.out.println("it is negative");
		}
		else {
			System.out.println("Positive");
		}

	}

}
