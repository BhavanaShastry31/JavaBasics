package First;

import java.util.Scanner;

public class EvenOdd {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the value of n: ");
		int n=sc.nextInt();
		int sum1=0,sum2=0,x=0;
		while(n!=0) {
			if(x%2==0 || x==0) {
				sum1+=n%10;
			}
			else {
				sum2+=n%10;
			}
			n=n/10;
			x++;
		}
		System.out.println(sum1);
		System.out.println(sum2);
	}

}
