package First;

import java.util.Arrays;
import java.util.Scanner;

public class Decimal_num {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("enter a floating number: ");
		double y=sc.nextDouble();
		String str = Double.toString(y);
		String[] x=str.split(".");
		System.out.println(Arrays.toString(x));
	}

}
