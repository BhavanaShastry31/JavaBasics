package First;

import java.util.Scanner;

public class Seventh {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter an integer from 1 to 12");
		int a= sc.nextInt();
		if(a==1) {
			System.out.println("31 days");
		}
		else if(a==2) {
			System.out.println("29 days");
		}
		else if(a==3) {
			System.out.println("31 days");
		}
		else if(a==4) {
			System.out.println("30 days");
		}
		else if(a==5) {
			System.out.println("31 days");
		}
		else if(a==6) {
			System.out.println("30 days");
		}
		else if(a==7) {
			System.out.println("31 days");
		}
		else if(a==8) {
			System.out.println("31days");
		}
		else if(a==9) {
			System.out.println("30 days");
		}
		else if(a==10) {
			System.out.println("31 days");
		}
		else if(a==11) {
			System.out.println("30 days");
		}
		else if(a==12) {
			System.out.println("31 days");
		}
		else {
			System.out.println("please enter an integer between 1 to 12 for month");
		}

	}

}
