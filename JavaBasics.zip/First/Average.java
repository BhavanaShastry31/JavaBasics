package First;

import java.util.Scanner;

public class Average {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		int a[]=new int[5];
		for(int i=0;i<5;i++) {
			System.out.println("enter the value of n1: ");
		    a[i]=sc.nextInt();
		}
		int sum=0;
		for(int elemt:a) {
			sum=sum+elemt;
		}
		int avg=sum/5;
	    System.out.println("sum="+sum+" and avg="+avg);
			

	}

}
