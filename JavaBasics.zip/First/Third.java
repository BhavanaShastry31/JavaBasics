package First;

import java.util.Scanner;

public class Third {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("enter an integer between 1 to 7");
		int a=sc.nextInt();
		if(a==1) {
			System.out.println("sunday");
		}
		else if(a==2) {
			System.out.println("monday");
		}
		else if(a==3) {
			System.out.println("tuesday");
		}
		else if(a==4) {
			System.out.println("Wednesday");
		}
		else if(a==5){
			System.out.println("Thursday");
		}
		else if(a==6){
			System.out.println("Friday");
		}
		else {
			System.out.println("Saturday");
		}

	}
}
