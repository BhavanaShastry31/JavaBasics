package First;

import java.util.Scanner;

public class Fourth {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter an alphabet");
		String a= sc.nextLine();
		
		if((a.length())>1) {
			System.out.println("error ");
		}
		if((a=="a")||(a=="e")||(a=="i")||(a=="o")||(a=="u")) {
			System.out.println("vowel");
		}
		else if((a=="A")||(a=="e")||(a=="i")||(a=="o")||(a=="u")) {
			System.out.println("vowel");
		}
		else {
			System.out.println("consonant");
		}
		

	}

}
