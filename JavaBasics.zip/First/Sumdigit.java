package First;

import java.util.Scanner;

public class Sumdigit {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the value of n: ");
		int n=sc.nextInt();
		int x=1;
		int sum=0;
		while(x!=0) {
			x=n%10;
			n=n/10;
			sum=sum+x;
		}
		System.out.println(sum);

	}

}
