package First;

import java.util.Scanner;

public class Leapyear {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("enter an integer");
		int a=sc.nextInt();
		if(a%400==0) {
			System.out.println("leap year");
		}
		else if(a%100==0) {
			System.out.println("not a leap year");
		}
		else if(a%4==0) {
			System.out.println("leap year");
		}
		else {
			System.out.println("not a leap year");
		}
	}

}
