package First;

import java.util.Arrays;
import java.util.Scanner;

public class Q {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("enter a string: ");
		String x=sc.nextLine();
		String z="";
		
		for(int i=0;i<x.length();i++) {
			if(z.contains(String.valueOf(x.charAt(i)))==false){
				z=z+x.charAt(i);
			}
			
		}
		int[] big_count=new int[z.length()];
		for(int i=0;i<z.length();i++) {
			int count=0;
			for(int j=0;j<x.length();j++) {
				if(z.charAt(i)==x.charAt(j)) {
					count=count+1;
				}
			}
			big_count[i]=count;
		}
		System.out.println(Arrays.toString(z.split("")));
		System.out.println(Arrays.toString(big_count));
			
		
	}

}
