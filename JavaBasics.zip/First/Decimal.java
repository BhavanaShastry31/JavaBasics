package First;

public class Decimal {
	

}
