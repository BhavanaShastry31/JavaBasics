package First;

import java.util.Scanner;

public class Sixth {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("enter a number");
		double a=sc.nextInt();
				if(a==0.0) {
			System.out.println(0);
		}
		else if(Math.abs(a)<1) {
			System.out.println("small");
		}
		else if( Math.abs(a)>100000) {
			System.out.println("Large");
		}
		else if(a<0.0) {
			System.out.println("negative");
		}
		else {
			System.out.println("positive");
		}

	}

}
