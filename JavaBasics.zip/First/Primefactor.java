package First;

import java.util.Scanner;

public class Primefactor {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the value of n: ");
		int n=sc.nextInt();
		
		for(int i=2;i<n;i++) {
			if(n%i==0) {
				boolean flag=false;
				for (int j= 2; j<= i / 2; ++j) {
				      // condition for nonprime number
				      if (i % j == 0) {
				        flag = true;
				        break;
				      }
				}
				if (!flag) {
					System.out.println(i);
				}
			}
		}
	}

}
