package First;

import java.util.Scanner;

public class Palindrome {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the value of n: ");
		int n=sc.nextInt();
		int rem,rev=0,temp=n;
		while(temp!=0) {
			rem=n%10;
			temp=temp/10;
			rev=rev*10+rem;
		}
		if(n==rev) {
			System.out.println("it is a palindrome: ");
		}
		else {
			System.out.println("not a palindrome");
		}
	}
}