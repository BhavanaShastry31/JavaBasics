package First;

import java.util.Scanner;

public class Digitpresent {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the value of n: ");
		int n=sc.nextInt();
		System.out.println("enter the value of x: ");
		int x=sc.nextInt();
		while(n!=0) {
			int y=n%10;
			if(y==x) {
				System.out.println("digit is present");
				break;
			}
			n=n/10;
		}
		if(n==0) {
			System.out.println("digit is not present");
		}
	}

}
